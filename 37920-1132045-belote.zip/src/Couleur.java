//=====================================================
// definition des couleurs
//=====================================================
class Couleur {
	String nom;
	Couleur ( String nomCouleur ){
		this.nom = nomCouleur ;
	}
}